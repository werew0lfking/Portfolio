package a2;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Level implements LevelInterface{
	
	int height = 4;
	int width = 4;
	int goalX;
	int goalY;
	int playerX;
	int playerY;
	int [][] level;
	int currentNumber;
	int moveCounter = 0;
	ArrayList<String> myMovesDirection = new ArrayList<String>();
	ArrayList<Integer> myMovesDistance = new ArrayList<Integer>();
	int currentLevel = 1;
	ArrayList<String> myMoves = new ArrayList<String>();
	
	public void ChangeLevel(int wantedLevel) {				//Feature 15 change level
		if (wantedLevel == 10 || wantedLevel < 10) {
			currentLevel = wantedLevel;
		}
		else {
			
		}
	}
	
	
	
	public void CreateLevel() {								//Feature 1 Create Level	
		switch (currentLevel) {
			case 1:
				height = 4;
				width = 4;
				break;
			case 2:
				height = 4;
				width = 4;
				break;
			case 3:
				height = 4;
				width = 4;
				break;
			case 4:
				height = 5;
				width = 5;
				break;
			case 5:
				height = 5;
				width = 5;
				break;
			case 6:
				height = 5;
				width = 5;
				break;
			case 7:
				height = 6;
				width = 6;
				break;
			case 8:
				height = 6;
				width = 6;
				break;
			case 9:
				height = 6;
				width = 6;
				break;
			case 10:
				height = 6;
				width = 6;
				break;
		}
		level = new int [height] [width];
		for (int x = 0; x < height; x++)
        {
            for (int y = 0; y < width; y++)
            {
                level[x][y] = 1; 
            }
        }
	} 
	
	public int GetLevelWidth() {
		return width;
	}
	
	public int GetLevelHeight() {
		return height;
	}
	
	public void CreatePlayer() {							//Feature 2 set default player location
		playerX = 0;
		playerY = 0;
	}
	
	public int GetPlayerX() {
		return playerX;
	}
	
	public int GetPlayerY() {
		return playerY;
	}
	
	public void MovePlayerUp() {							//Feature 3 move player up			Feature 12 Move counter		Feature 13 Move List
		currentNumber = GetCurrentNumber();
		if (playerY - currentNumber < 0){
			
		}
		else {
			currentNumber = GetCurrentNumber();
			playerY = playerY - currentNumber;
			moveCounter++;
			myMovesDirection.add("Up");
			myMovesDistance.add(currentNumber);
		}
		
	}
	
	public void MovePlayerDown() {							//Feature 4 move player down		Feature 12 Move counter		Feature 13 Move List
		currentNumber = GetCurrentNumber();
		if (playerY + currentNumber > height){
			
		}
		else {
		currentNumber = GetCurrentNumber();
		playerY = playerY + currentNumber;
		moveCounter++;
		myMovesDirection.add("Down");
		myMovesDistance.add(currentNumber);
		}
	}
	
	public void MovePlayerLeft() {							//Feature 5 move player left		Feature 12 Move counter		Feature 13 Move List
		currentNumber = GetCurrentNumber();
		if (playerX - currentNumber < 0){
			
		}
		else {
		currentNumber = GetCurrentNumber();
		playerX = playerX - currentNumber;
		moveCounter++;
		myMovesDirection.add("Left");
		myMovesDistance.add(currentNumber);
		}
	}
	
	public void MovePlayerRight() {							//Feature 6 move player right		Feature 12 Move counter		Feature 13 Move List
		currentNumber = GetCurrentNumber();
		if (playerX + currentNumber > width){
			
		}
		else {
		playerX = playerX + currentNumber;
		moveCounter++;
		myMovesDirection.add("Right");
		myMovesDistance.add(currentNumber);
		}
	}
	
	public int MoveCounter() {								//Feature 12 Move counter
		return moveCounter;
	}

	public void AddGoal() {				//Feature 7 add goal
		switch (currentLevel) {
		case 1:
			goalX = 3;
			goalY = 3;
			break;
		case 2:
			goalX = 3;
			goalY = 3;
			break;
		case 3:
			goalX = 3;
			goalY = 3;
			break;
		case 4:
			goalX = 4;
			goalY = 4;
			break;
		case 5:
			goalX = 4;
			goalY = 4;
			break;
		case 6:
			goalX = 4;
			goalY = 4;
			break;
		case 7:
			goalX = 5;
			goalY = 5;
			break;
		case 8:
			goalX = 5;
			goalY = 5;
			break;
		case 9:
			goalX = 5;
			goalY = 5;
			break;
		case 10:
			goalX = 5;
			goalY = 5;
			break;
		}
	}
	
	public int GetGoalX() {
		return goalX;
	}
	
	public int GetGoalY() {
		return goalY;
	}

	public boolean PlayerOnGoal() {										//Feature 8 check if player is on goal
		if (playerX == goalX & playerY == goalY) {
			return true;
		} else return false;
	}
	
	public void AddNumbers(int number, int gridX, int gridY) {		 	//Feature 9 add number to square
		level[gridX][gridY] = number;
	}
	
	public int GetCurrentNumber() {										//Feature 10 get square's number
		return level[playerX][playerY];
	}

	
	public void RestartLevel() {										//Feature 11 Reset player
		CreatePlayer();	
	}
	
	public void Undo() {												//Feature 14 Undo
		String lastDirestion = myMovesDirection.get(myMovesDirection.size() - 1);
		int lastDistance = myMovesDistance.get(myMovesDistance.size() - 1);
		if (lastDirestion == "Up") {
			playerY = playerY + lastDistance;
		}
		else if (lastDirestion == "Down") {
			playerY = playerY - lastDistance;
		}
		else if (lastDirestion == "Left") {
			playerX = playerX + lastDistance;
		}
		else if (lastDirestion == "Right"){
			playerX = playerX - lastDistance;
		}
		else {
			
		}
	}
	
	 public static <T, U> List<U>											
	 convertIntListToStringList(List<T> myMovesDistance,Function<T, U> function)
	    {
	        return myMovesDistance.stream()
	            .map(function)
	            .collect(Collectors.toList());
	    }
	
	public void RouteTaken() {												//Feature 16 Route taken
		List<String> listOfString = convertIntListToStringList(
				myMovesDistance,
	            s -> String.valueOf(s));
		int b = 0;
		while (b < moveCounter) {
			myMoves.add(myMovesDirection.get(b));
			myMoves.add(listOfString.get(b));
			b++;
		}
	}
	
	public ArrayList<String> GetMyMoves() {
		return myMoves;
	}
		
}
