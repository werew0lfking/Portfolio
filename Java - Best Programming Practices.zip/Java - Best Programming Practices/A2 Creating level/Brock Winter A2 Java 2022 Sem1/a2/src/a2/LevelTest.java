package a2;


import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class LevelTest extends Level{

	@Test
	public void testLevel1Width() {
		CreateLevel();
		int expectedWidth = 4;
		int actualWidth = GetLevelWidth();
		assertEquals(expectedWidth, actualWidth); 
	}

	@Test
	public void testLevel1Height() {
		CreateLevel();
		int expectedHeight = 4;
		int actualHeight = GetLevelHeight();
		assertEquals(expectedHeight, actualHeight); 
	}
	
	@Test
	public void testLevel4Height() {
		ChangeLevel(4);
		CreateLevel();
		AddGoal();
		int expectedHeight = 5;
		int actualHeight = GetLevelHeight();
		assertEquals(expectedHeight, actualHeight); 
	}
	
	@Test
	public void testLevel8Width() {
		ChangeLevel(8);
		CreateLevel();
		AddGoal();
		int expectedWidth = 6;
		int actualWidth = GetLevelWidth();
		assertEquals(expectedWidth, actualWidth);
	}
	
	@Test
	public void testLevel4PlayerLocation() {
		ChangeLevel(4);
		CreateLevel();
		CreatePlayer();
		AddGoal();
		int expectedPlayerX = 0;
		int expectedPlayerY = 0;
		int actualPlayerX = GetPlayerX();
		int actualPlayerY = GetPlayerY();
		assertEquals(expectedPlayerX, actualPlayerX & actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testLevel1PlayerLacation() {
		ChangeLevel(1);
		CreateLevel();
		CreatePlayer();
		AddGoal();
		int expectedPlayerX = 0;
		int expectedPlayerY = 0;
		int actualPlayerX = GetPlayerX();
		int actualPlayerY = GetPlayerY();
		assertEquals(expectedPlayerX, actualPlayerX & actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testDefaultLevelCurrentNumber1() {
		CreateLevel();
		CreatePlayer();
		int expectedNumber = 1;
		int actualNumber = GetCurrentNumber();
		assertEquals(expectedNumber, actualNumber ); 
	}
	
	@Test
	public void testDefaultLevelCurrentNumber2() {
		CreateLevel();
		CreatePlayer();
		AddNumbers(2, 0, 0);
		int expectedNumber = 2;
		int actualNumber = GetCurrentNumber();
		assertEquals(expectedNumber, actualNumber ); 
	}
	
	@Test
	public void testChangeLevel() {
		ChangeLevel(100);
		CreateLevel();
		AddGoal();
		int expectedWidth = 4;
		int actualWidth = GetLevelWidth();
		assertEquals(expectedWidth, actualWidth);
	}
	
	@Test
	public void testMoveDownPlayerLocation1() {
		CreateLevel();
		CreatePlayer();
		MovePlayerDown();
		int expectedPlayerY = 1;
		int actualPlayerY = GetPlayerY();
		assertEquals(actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testMoveDownPlayerLocation2() {
		CreateLevel();
		CreatePlayer();
		AddNumbers(2, 0, 0);
		MovePlayerDown();
		int expectedPlayerY = 2;
		int actualPlayerY = GetPlayerY();
		assertEquals(actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testMoveDownPlayerLocation3() {
		CreateLevel();
		CreatePlayer();
		AddNumbers(6, 0, 0);
		MovePlayerDown();
		int expectedPlayerY = 0;
		int actualPlayerY = GetPlayerY();
		assertEquals(actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testMoveRightPlayerLocation1() {
		CreateLevel();
		CreatePlayer();
		MovePlayerRight();
		int expectedPlayerX = 1;
		int actualPlayerX = GetPlayerX();
		assertEquals(expectedPlayerX, actualPlayerX); 
	}
	
	@Test
	public void testMoveRightPlayerLocation2() {
		CreateLevel();
		CreatePlayer();
		AddNumbers(2, 0, 0);
		MovePlayerRight();
		int expectedPlayerX = 2;
		int actualPlayerX = GetPlayerX();
		assertEquals(expectedPlayerX, actualPlayerX); 
	}
	
	@Test
	public void testMoveRightPlayerLocation3() {
		CreateLevel();
		CreatePlayer();
		AddNumbers(7, 0, 0);
		MovePlayerRight();
		int expectedPlayerX = 0;
		int actualPlayerX = GetPlayerX();
		assertEquals(expectedPlayerX, actualPlayerX); 
	}
	

	@Test
	public void testMoveLeftPlayerLocation1() {
		CreateLevel();
		CreatePlayer();
		MovePlayerRight();
		MovePlayerLeft();
		int expectedPlayerX = 0;
		int actualPlayerX = GetPlayerX();
		assertEquals(expectedPlayerX, actualPlayerX); 
	}
	
	@Test
	public void testMoveLeftPlayerLocation2() {
		CreateLevel();
		CreatePlayer();
		AddNumbers(2, 0, 0);
		MovePlayerRight();
		MovePlayerLeft();
		int expectedPlayerX = 1;
		int actualPlayerX = GetPlayerX();
		assertEquals(expectedPlayerX, actualPlayerX); 
	}
	
	@Test
	public void testMoveLeftPlayerLocation3() {
		CreateLevel();
		CreatePlayer();
		AddNumbers(6, 0, 0);
		MovePlayerRight();
		MovePlayerLeft();
		int expectedPlayerX = 0;
		int actualPlayerX = GetPlayerX();
		assertEquals(expectedPlayerX, actualPlayerX); 
	}
	
	@Test
	public void testMoveUpPlayerLocation1() {
		CreateLevel();
		CreatePlayer();
		MovePlayerDown();
		MovePlayerUp();
		int expectedPlayerY = 0;
		int actualPlayerY = GetPlayerY();
		assertEquals(actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testMoveUpPlayerLocation2() {
		CreateLevel();
		CreatePlayer();
		AddNumbers(2, 0, 0);
		MovePlayerDown();
		MovePlayerUp();
		int expectedPlayerY = 1;
		int actualPlayerY = GetPlayerY();
		assertEquals(actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testMoveUpPlayerLocation3() {
		CreateLevel();
		CreatePlayer();
		MovePlayerUp();
		int expectedPlayerY = 0;
		int actualPlayerY = GetPlayerY();
		assertEquals(actualPlayerY, expectedPlayerY); 
	}
	
	
	@Test
	public void testRestartPlayerLocation() {
		CreateLevel();
		CreatePlayer();
		MovePlayerDown();
		RestartLevel();
		int expectedPlayerX = 0;
		int expectedPlayerY = 0;
		int actualPlayerX = GetPlayerX();
		int actualPlayerY = GetPlayerY();
		assertEquals(expectedPlayerX, actualPlayerX & actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testUndoMoveDown() {
		CreateLevel();
		CreatePlayer();
		MovePlayerDown();
		Undo();
		int expectedPlayerY = 0;
		int actualPlayerY = GetPlayerY();
		assertEquals(actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testUndoMoveUp() {
		ChangeLevel(5);
		CreateLevel();
		CreatePlayer();
		AddGoal();
		MovePlayerDown();
		MovePlayerUp();
		Undo();
		int expectedPlayerY = 1;
		int actualPlayerY = GetPlayerY();
		assertEquals(actualPlayerY, expectedPlayerY); 
	}
	
	@Test
	public void testUndoMoveLeft() {
		ChangeLevel(6);
		CreateLevel();
		CreatePlayer();
		AddGoal();
		MovePlayerRight();
		MovePlayerLeft();
		Undo();
		int expectedPlayerX = 1;
		int actualPlayerX = GetPlayerX();
		assertEquals(expectedPlayerX, actualPlayerX); 
	}
	
	@Test
	public void testUndoMoveRight() {
		ChangeLevel(7);
		CreateLevel();
		CreatePlayer();
		AddGoal();
		MovePlayerRight();
		Undo();
		int expectedPlayerX = 0;
		int actualPlayerX = GetPlayerX();
		assertEquals(expectedPlayerX, actualPlayerX); 
	}
	
	@Test
	public void testMoveCounter0Moves() {
		ChangeLevel(9);
		CreateLevel();
		CreatePlayer();
		AddGoal();
		int expectedMoveCount = 0;
		int actualMoveCount = MoveCounter();
		assertEquals(expectedMoveCount, actualMoveCount); 
	}
	
	@Test
	public void testMoveCounter1Move() {
		ChangeLevel(10);
		CreateLevel();
		CreatePlayer();
		AddGoal();
		MovePlayerDown();
		int expectedMoveCount = 1;
		int actualMoveCount = MoveCounter();
		assertEquals(expectedMoveCount, actualMoveCount); 
	}
	
	@Test
	public void testAddGoal() {
		CreateLevel();
		AddGoal();
		int expectedGoalX = 3;
		int actualGoalX = GetGoalX();
		assertEquals(expectedGoalX, actualGoalX); 
	}
	
	@Test
	public void testAddGoal2() {
		ChangeLevel(2);
		CreateLevel();
		AddGoal();
		int expectedGoalY = 3;
		int actualGoalY = GetGoalY();
		assertEquals(expectedGoalY, actualGoalY); 
	}
	
	@Test
	public void testPlayerOnGoalTrue() {
		ChangeLevel(3);
		CreateLevel();
		AddGoal();
		MovePlayerDown();
		MovePlayerDown();
		MovePlayerDown();
		MovePlayerRight();
		MovePlayerRight();
		MovePlayerRight();
		boolean expectedResult = true;
		boolean actualResult = PlayerOnGoal();
		assertEquals(expectedResult, actualResult); 
	}
	
	@Test
	public void testPlayerOnGoalFalse() {
		ChangeLevel(3);
		CreateLevel();
		AddGoal();
		boolean expectedResult = false;
		boolean actualResult = PlayerOnGoal();
		assertEquals(expectedResult, actualResult); 
	}
	
	@Test
	public void testRouteTaken() {
		ChangeLevel(3);
		CreateLevel();
		MovePlayerRight();
		RouteTaken();
		ArrayList<String> expectedMoves = new ArrayList<String>();
		expectedMoves.add("Right");
		expectedMoves.add("1");
		ArrayList<String> actualMoves = GetMyMoves();
		assertEquals(expectedMoves, actualMoves ); 
	}
	
}
