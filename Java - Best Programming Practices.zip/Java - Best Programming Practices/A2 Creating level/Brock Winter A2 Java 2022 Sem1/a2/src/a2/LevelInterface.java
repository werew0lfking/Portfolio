package a2;

public interface LevelInterface {

	void CreateLevel();
	
	void MovePlayerUp();
	
	void MovePlayerDown();
	
	void MovePlayerLeft();
	
	void MovePlayerRight();
	
	void AddGoal();
	
	void AddNumbers(int levelDifficulty,int gridX, int gridY);
}
