use [Vaccinations]
go

CREATE OR ALTER VIEW VaccinationSlots AS
SELECT [longName], [maxSlots], max([slot]) as highestSlotFilled
FROM [dbo].[Place]
JOIN [dbo].[Appointment] on [dbo].[Appointment].[placeId]=[dbo].[Place].[id]
GROUP BY DAY([apptTime]), [longName],[maxSlots];

CREATE OR ALTER VIEW PeopleWhoMissedBookings AS
SELECT [preferredName], [eMail], [phone] 
FROM [dbo].[Person]
JOIN OldAppointment on OldAppointment.personId = Person.NHI;

CREATE OR ALTER VIEW yearsSinceVacinated AS
SELECT [preferredName], datediff(YY, apptTime, SYSDATETIME()) as yearsSinceVacinated
FROM [dbo].[Person]
JOIN [dbo].[Appointment] on [dbo].[Appointment].[personId]=[dbo].[Person].[NHI]
ORDER BY yearsSinceVacinated;

CREATE OR ALTER VIEW VacinatorVactionationCount AS
SELECT [preferredName], count([id]) as VactionationCount
FROM [dbo].[Appointment]
JOIN [dbo].[Vaccinator] on [dbo].[Appointment].[vaccinator] = [dbo].[Vaccinator].[preferredName]
GROUP BY [preferredName];


DROP TRIGGER IF EXISTS newWidgetSale;
DELIMITER //
CREATE TRIGGER appointmentCancelation AFTER DELETE ON [dbo].[Appointment]
    FOR EACH ROW
    BEGIN
         INSERT [dbo].[OldAppointment] VALUES ([personId],'Changed appointment');
    END //
DELIMITER ;


drop procedure doubleBookingCheck



create procedure doubleBookingCheck (IN ([apptTime] < GETDATE()) date)
begin

select [preferredName]  
where [apptTime].[vialNumber] = [vialNumber] GETDATE();

end$$





DROP PROCEDURE IF EXISTS addPersonToAppointment
GO

CREATE PROCEDURE addPersonToAppointment
	@id int, 
	@personId char(10) = NULL,
	@vaccineNumber tinyint = 1
AS
BEGIN
	DECLARE @NHI char(10) = NULL
	SET @NHI = (SELECT NHI FROM Person WHERE NHI=@personId)
	IF @NHI IS NULL
	BEGIN
		
		INSERT INTO Person SELECT * FROM AllPeople WHERE NHI=@personId
	END
	IF (SELECT COUNT(NHI) FROM Person WHERE NHI=@personId) = 1 
	BEGIN
		UPDATE Appointment
		SET personId = @personId, vaccineNumber = @vaccineNumber
			WHERE id=@id
	END
END