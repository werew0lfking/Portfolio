USE [Vaccinations]
GO
CREATE USER [Jacinda Ardern] FOR LOGIN [Jacinda]
CREATE USER [Shayne Hunter] FOR LOGIN [Shayne]
CREATE USER [Dr Ashley Bloomfield] FOR LOGIN [Ashley]
CREATE USER [Bob White] FOR LOGIN [Bob]
CREATE USER [Tim Black] FOR LOGIN [Tim]
CREATE USER [Simon Dallow] FOR LOGIN [Simon]
CREATE USER [Melissa Stokes] FOR LOGIN [Melissa]
GO

EXEC sp_addrolemember 'Admins', 'Jacinda Ardern';
EXEC sp_addrolemember 'Admins', 'Shayne Hunter';
EXEC sp_addrolemember 'Admins', 'Dr Ashley Bloomfield';
EXEC sp_addrolemember 'Users', 'Bob White';
EXEC sp_addrolemember 'Users', 'Tim Black';
EXEC sp_addrolemember 'Guests', 'Simon Dallow';
EXEC sp_addrolemember 'Guests', 'Melissa Stokes';
GO