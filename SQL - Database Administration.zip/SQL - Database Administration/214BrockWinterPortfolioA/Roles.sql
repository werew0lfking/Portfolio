USE [Vaccinations]
GO
CREATE ROLE [Admins]
CREATE ROLE [Users]
CREATE ROLE [Guests]
GO

ALTER ROLE [Admins] ADD MEMBER [Jacinda Ardern]
ALTER ROLE [Admins] ADD MEMBER [Shayne Hunter]
ALTER ROLE [Admins] ADD MEMBER [Dr Ashley Bloomfield]
ALTER ROLE [Users] ADD MEMBER [Bob White]
ALTER ROLE [Users] ADD MEMBER [Tim Black]
ALTER ROLE [Guests] ADD MEMBER [Simon Dallow]
ALTER ROLE [Guests] ADD MEMBER [Melissa Stokes]
GO