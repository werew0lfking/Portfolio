use [Vaccinations]
GO
GRANT SELECT ON [dbo].[Place] TO [Guests]				--grants access to a Place Table 
GRANT SELECT ON [sys].[check_constraints] TO [Guests]	--grants access to a specific view
GO

GRANT INSERT ON [dbo].[AllPeople] TO [Users]
GRANT SELECT ON [dbo].[AllPeople] TO [Users]
GRANT UPDATE ON [dbo].[AllPeople] TO [Users]

GRANT INSERT ON [dbo].[Appointment] TO [Users]
GRANT SELECT ON [dbo].[Appointment] TO [Users]
GRANT UPDATE ON [dbo].[Appointment] TO [Users]

GRANT INSERT ON [dbo].[OldAppointment] TO [Users]
GRANT SELECT ON [dbo].[OldAppointment] TO [Users]
GRANT UPDATE ON [dbo].[OldAppointment] TO [Users]

GRANT INSERT ON [dbo].[Person] TO [Users]
GRANT SELECT ON [dbo].[Person] TO [Users]
GRANT UPDATE ON [dbo].[Person] TO [Users]

GRANT INSERT ON [dbo].[Place] TO [Users]
GRANT SELECT ON [dbo].[Place] TO [Users]
GRANT UPDATE ON [dbo].[Place] TO [Users]
GO