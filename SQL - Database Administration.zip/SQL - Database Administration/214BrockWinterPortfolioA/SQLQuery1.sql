use [Vaccinations];
GO

select * from [dbo].[AllPeople];
go