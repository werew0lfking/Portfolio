-- =============================================
-- Author: Brock Winter
-- Date: 13.09.2021
-- Description:	Procedure to create a New Place
-- =============================================
DROP PROCEDURE IF EXISTS CreatePlace
GO

CREATE PROCEDURE CreatePlace
	@id char(10) = '', 
	@longName nvarchar(50) = '',
	@maxSlots tinyint = NULL
AS
BEGIN
	INSERT INTO Place(id, longName, maxSlots)
		VALUES (@id, @longName, @maxSlots)
END
GO