-- Write your code here
-- Choose the data base, delete teh previous procedure if it is there
USE Vaccinations
GO


-- Create the procedure
CREATE PROCEDURE bulkLoadVaccinators
	-- Loads a file of places into the Vaccination table.  No error checking.
	@fileName varchar(100) = '',	-- The file name where the data is being loaded from
	@startApptNumber int,			-- Start and end slot to load the data
	@endApptNumber int
AS
BEGIN
	DECLARE @sqlString varchar(512) = '' -- The string that is being executed to bulk load the data
	
	--  Create the temporary table to load the data by copying the structure
	DROP TABLE IF EXISTS #newVaccinators
	SELECT TOP 0 * INTO #newVaccinators FROM Vaccinator
	CREATE TABLE #newVaccinators (
		iRDNumber char(10),				-- The Vaccinator
		preferredName nvarchar(20)
	)






	-- Create and execute the sql string.  The quotes are important
	SET @sqlString = '
	BULK INSERT #vaccinatorPreferred
	FROM '''  + @fileName + '''
	WITH (
		FIRSTROW = 2,
		FIELDTERMINATOR = '','',
		ROWTERMINATOR=''\n''
	)'
	EXECUTE (@sqlString)

	-- Use a cursor to loop through teh temporary table, and load the data into the permanent table
	-- Variables data read from



	DECLARE @iRDNumber char(10)
	DECLARE @preferredName char(12)

	DECLARE newPlacesCursor CURSOR FOR
			SELECT iRDNumber FROM #newVaccinators

	OPEN newPlacesCursor

	FETCH NEXT FROM newPlacesCursor INTO @iRDNumber

	WHILE @startApptNumber <= @endApptNumber
	BEGIN
		SELECT @preferredName = preferredName
		FROM #newVaccinators
		EXEC createVaccinator @iRDNumber=@iRDNumber, @preferredName=@preferredName
		FETCH NEXT FROM newPlacesCursor INTO @iRDNumber
	END

	CLOSE newVaccinatorsCursor
	DEALLOCATE newVaccinatorsCursor
	DROP TABLE #newVaccinators
END 
GO


-- Test
-- Testing data
--DELETE FROM Vaccinator
--SELECT * FROM Vaccinator
--EXEC bulkLoadVaccinators @fileName = 'C:\Temp\Vaccine2021\Vaccinators.csv'
--SELECT * FROM Vaccinator


