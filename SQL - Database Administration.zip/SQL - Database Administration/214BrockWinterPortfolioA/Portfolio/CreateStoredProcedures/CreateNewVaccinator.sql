-- =============================================
-- Description:	Procedure to create a New Vaccinator
-- =============================================
-- Write your code here
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Brock Winter
-- Create date: 30,09,2021
-- Description:	Vaccinator
-- =============================================
CREATE PROCEDURE createVaccinator 
@iRDNumber VARCHAR(10),
@preferredName NVARCHAR(20)
AS
BEGIN
	INSERT INTO [dbo].[Vaccinator] (iRDNumber, preferredName)
	VALUES (@iRDNumber, @preferredName)
END
GO
