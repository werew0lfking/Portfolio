-- Write Your Code here
-- Testing data
--DELETE FROM Place
--SELECT * FROM Place
--EXEC bulkLoadVaccinators @fileName = 'C:\Temp\Vaccine2021\Sites.csv'
--SELECT * FROM Place

USE Vaccinations

DROP PROCEDURE IF EXISTS bulkAddPlaces
GO

CREATE PROCEDURE bulkAddPlaces
	-- Loads a file of appointments into the Appointment table.  No error checking.
	@fileName varchar(100) = '',	-- The file naem where the data is being loaded from
	@startApptNumber int,			-- Start and end slot to load the data
	@endApptNumber int
AS
BEGIN
	DECLARE @sqlString varchar(512) = '' -- The string that is being executed to bulk load the data
	
	--  Create the temporary table to load teh vaccinators into
	DROP TABLE IF EXISTS #newPlace
	SELECT TOP 0 * INTO #newPlace FROM Place
	/*CREATE TABLE #newPlace (
		id char(10),				-- The place
		longName nvarchar(50),		-- The place long name
		maxSlot tinyint				-- The max slot
		
	)*/
	
	SET @splString = '
	BULK INSERT #newPlace
	FROM ''' + @fileName + '''
	WITH (
		FIRSTROW = 2,
		FIELDTERMINATOR = '','',
		ROWTERMINATOR=''\n''
		)'
		EXECUTE (@sqlString)
		
		DECLARE @placeId char(10)
		DECLARE @longName nvarchar(50)
		DECLARE @maxSlot tinyint
		
		DECLARE newPlacesCursor CURSOR FOR
			SELECT id FROM #newPlace
		
		OPEN newPlacesCursor
		
		FETCH NEXT FROM newPlacesCursor INTO @placeId
		WHILE @@FETCH_STATUS = 0
			BEGIN
				SELECT @longName = longName, @maxSlot = maxSlot
					FROM #newPlaces
					WHERE id = @placeId
				EXEC createPlace @shortname=@placeId, @longName=@longName, @maxSlot=@maxSlot
				FETCH NEXT FROM newPlacesCursor INTO @placeId
			END
			
		CLOSE newPlacesCursor
		DEALLOCATE newPlacesCursor
		DROP TABLE #newPlaces
END
GO