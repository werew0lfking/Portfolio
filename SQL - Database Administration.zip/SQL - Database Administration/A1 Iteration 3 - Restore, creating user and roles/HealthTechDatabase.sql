CREATE DATABASE HealthTech;
USE HealthTech;

CREATE TABLE IF NOT EXISTS Worker(
workerID int primary key,
workerFirstName varchar(20),
workerLastName varchar(20),
workerEmail varchar(60)
) engine = InnoDB;

CREATE TABLE IF NOT EXISTS Contactor(
contactorID int primary key,
contactorFirstName varchar(20),
contactorLastName varchar(20),
contactorEmail varchar(60)
) engine = InnoDB;

CREATE TABLE IF NOT EXISTS Carer(
carerID int primary key,
carerFirstName varchar(20),
carerLastName varchar(20),
carerEmail varchar(60)
) engine = InnoDB;

CREATE TABLE IF NOT EXISTS Patient(
patientID int primary key,
patientFirstName varchar(20),
patientLastName varchar(20),
contactorID int,
contactorFirstName varchar(20),
contactorLastName varchar(20),
carerID int,
carerFirstName varchar(20),
carerLastName varchar(20),
foreign key (carerID) references Carer (carerID),
foreign key (contactorID) references Contactor (contactorID)
) engine = InnoDB;

CREATE TABLE IF NOT EXISTS Contact(
contactID int primary key,
contactDescription varchar(200),
actionsTaken varchar(20),
contactDate date,
patientID int,
patientFirstName varchar(20),
patientLastName varchar(20),
contactorID int,
contactorFirstName varchar(20),
contactorLastName varchar(20),
workerID int,
workerFirstName varchar(20),
workerLastName varchar(20),
carerID int,
carerFirstName varchar(20),
carerLastName varchar(20),
foreign key (workerID) references Worker (workerID),
foreign key (contactorID) references Contactor (contactorID),
foreign key (patientID) references Patient (patientID),
foreign key (carerID) references Carer (carerID)
) engine = InnoDB;

insert into Worker values(1, 'John', 'smith', 'johnsmith@gmail.com');
insert into Worker values(2, 'Ben', 'snow', 'Bensnow@gmail.com');
insert into Worker values(3, 'Alex', 'grey', 'Alexgrey@gmail.com');

insert into Carer values(1, 'Sam', 'smith', 'samsmith@gmail.com');
insert into Carer values(2, 'Samy', 'smithy', 'samysmithy@gmail.com');
insert into Carer values(3, 'Same', 'smithe', 'samesmithe@gmail.com');

insert into Contactor values(1, 'Sal', 'white', 'salwhite@gmail.com');
insert into Contactor values(2, 'Saly', 'black', 'salyblack@gmail.com');
insert into Contactor values(3, 'Sally', 'gray', 'sallygray@gmail.com');

insert into Patient values(1, 'Sam', 'smith', 1, 'Sal', 'white', 1, 'Sam', 'smith');
insert into Patient values(2, 'Samy', 'smithy', 1, 'Sal', 'white', 2, 'Samy', 'smithy');
insert into Patient values(3, 'Same', 'smithe', 2, 'Saly', 'black', 3, 'Same', 'smithe');

insert into Contact values(1, 'Walk from bla to blaaa with sal and sam', 'Walk', '2021-07-11', 1, 'Sam', 'smith', 1, 'Sal', 'white', 2, 'Ben', 'snow', 1, 'Sam', 'smith');

insert into Worker values(4, 'Matt', 'house', 'Matthouse@gmail.com');
insert into Carer values(4, 'Samantha', 'smell', 'Samanthasmell@gmail.com');
insert into Contactor values(4, 'Amber', 'red', 'Amberred@gmail.com');
insert into Patient values(4, 'Croc', 'cane', 4, 'Amber', 'red', 4, 'Samantha', 'smell');
insert into Contact values(2, 'Tea and crumpets by the seaside', 'Snack', '2021-08-21', 4, 'Croc', 'cane', 4, 'Amber', 'red',4, 'Matt', 'house', 4, 'Samantha', 'smell');