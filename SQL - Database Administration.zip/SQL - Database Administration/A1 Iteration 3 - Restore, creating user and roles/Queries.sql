select carerID, carerFirstName
from carer
GROUP BY carerFirstName
ORDER BY carerFirstName;

create view ContractorName as
select contactorID, contactorFirstName, contactDate, contactDescription
from contact
where carerFirstName LIKE 's%' LIMIT 1;

select * from ContractorNames